#pragma once

#include <iostream>
#include <string>
#include "Swiat.h"
class Swiat;

class Organizm
{
protected:
	int sila;
	int inicjatywa;
	int posX;
	int posY;
	int wiek;
	char imie;
	Swiat& currWorld; 
public:
	virtual void akcja() = 0;
	virtual void kolizja() = 0;
	virtual void rysowanie() = 0;
	~Organizm();
};