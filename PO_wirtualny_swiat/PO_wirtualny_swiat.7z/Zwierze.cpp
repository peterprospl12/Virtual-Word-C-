#include <iostream>
#include "Zwierze.h"
#include <time.h>
void Zwierze::akcja() {
    int newX = posX; // aktualna pozycja x zwierz�cia
    int newY = posY; // aktualna pozycja y zwierz�cia

    while (true) {
        srand(time(0));
        int rand_number = (rand() % 8) + 1;

        char** currBoard = currWorld.getBoard();

        switch (rand_number) {
        case 1: // ruch w g�r�
            if (newY > 0) {
                newY--;
                break;
            }
        case 2: // ruch w d�
            if (newY < currWorld.getBoardSizeY()) {
                newY++;
                break;
            }
        case 3: // ruch w lewo
            if (newX > 0) {
                newX--;
                break;
            }
        case 4: // ruch w prawo
            if (newX < currWorld.getBoardSizeX()) {
                newX++;
                break;
            }
        case 5: // ruch sko�ny w g�r� i w lewo
            if (newX > 0 && newY > 0 ) {
                newX--;
                newY--;
                break;
            }
        case 6: // ruch sko�ny w g�r� i w prawo
            if (newX < currWorld.getBoardSizeX() && newY > 0 ) {
                newX++;
                newY--;
                break;
            }
        case 7: // ruch sko�ny w d� i w lewo
            if (newX > 0 && newY < currWorld.getBoardSizeY() ) {
                newX--;
                newY++;
                break;
            }
        case 8: // ruch sko�ny w d� i w prawo
            if (newX < currWorld.getBoardSizeX() && newY < currWorld.getBoardSizeY()) {
                newX++;
                newY++;
                break;
            }
        }

        // je�li pozycja zwierz�cia si� zmieni�a, zako�cz p�tl�
        if (newX != posX || newY != posY) {
            break;
        }
    }

    // zapisz now� pozycj� zwierz�cia
    //plansza[x][y] = nullptr;
    posX = newX;fg
    posY = newY;
    //plansza[x][y] = this;
}