#pragma once

#include <iostream>
#include "Organizm.h"
class Roslina : protected Organizm
{
	int iniciative = 0;
};