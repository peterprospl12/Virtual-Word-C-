#pragma once
#include <iostream>
#include "Organizm.h"
class Zwierze : protected Organizm
{
	virtual void akcja();
	virtual void kolizja();
};