#pragma once

#include <iostream>
#include <string>
#include "Organizm.h"
using std::string;

class Swiat
{
private:
	char** board;
	int BoardSizeX;
	int BoardSizeY;
	string organisism;
public:
	Swiat(int sizeX, int sizeY);
	void rysujSwiat();
	void wykonajTure();
	int getBoardSizeX();
	int getBoardSizeY();
	static void gotoxy(int x, int y);
	~Swiat();
	char** getBoard();
};