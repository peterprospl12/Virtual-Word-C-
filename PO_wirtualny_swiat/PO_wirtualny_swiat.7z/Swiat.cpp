#include <iostream>
#include "Swiat.h"
#include <conio.h>
#include <Windows.h>
using std::cout;
using std::endl;
using std::cin;

Swiat::Swiat(int BoardSizeX, int BoardSizeY)
	:BoardSizeX(BoardSizeX), BoardSizeY(BoardSizeY)
{
	board = new char*[BoardSizeX];
	for (int i = 0; i < BoardSizeX; i++) {
		board[i] = new char[BoardSizeY];
	}

	for (int i = 0; i < BoardSizeX; i++) {
		for (int j = 0; j < BoardSizeY; j++) {
			board[i][j] = *".";
		}
	}
}


void Swiat::rysujSwiat() {
	system("cls");
	cout << "                       Piotr Sulewski 19254" << endl;
	for (int i = 0; i < 5; i++) {
		cout << endl;
	}
	for (int i = -1; i < BoardSizeX+1; i++) {
		for (int j = -1; j < BoardSizeY+1; j++) {
			if (j == -1) {
				cout << "                 # ";
			}
			else if (j == BoardSizeY) {
				cout << "#";
			}
			else if (i == -1 || i == BoardSizeX) {
				cout << "# ";
			}
			else {
				cout << board[i][j];
				cout << " ";
			}
		}
		cout << endl;
	}
}

int Swiat::getBoardSizeX() {
	return BoardSizeX;
}

int Swiat::getBoardSizeY() {
	return BoardSizeY;
}

char** Swiat::getBoard() {
	return board;
}

static void gotoxy(int x, int y)
{
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}



Swiat::~Swiat() {
	for (int i = 0; i < BoardSizeX; i++) {
		delete[] board[i];
	}
	delete[] board;
}