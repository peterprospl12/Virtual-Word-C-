#include <iostream>
#include "Swiat.h"
using std::cout;
using std::endl;
using std::cin;


int main() {
	int a;
	Swiat Galactic(20,20);
	while (true) {
		Galactic.rysujSwiat();
		cin >> a;
	}
	//Galactic.gotoxy(15, 15);
	cout << "jajko" << endl;

	return 0;
}